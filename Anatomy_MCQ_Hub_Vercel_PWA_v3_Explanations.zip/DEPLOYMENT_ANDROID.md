# Deploy the updated Anatomy MCQ Hub from Android

## A. Update the existing website without changing its URL

**Important:** Vercel Drop creates a new project each time. If you upload this ZIP to Vercel Drop, it will usually give you a new URL. To keep `anatomymcqhubvercelapp.vercel.app`, connect the existing Vercel project to a Git repository.

1. Download `Anatomy_MCQ_Hub_Vercel_PWA_v2.zip` and extract it on your phone.
2. In GitHub, create a repository such as `anatomy-mcq-hub`.
3. Upload the extracted project files to the repository's root. Make sure `index.html` is at the root, not inside another nested folder.
4. Open the Vercel dashboard and select the existing `anatomymcqhubvercelapp` project.
5. Open **Settings → Git** and connect the GitHub repository you created. If Vercel asks which branch to deploy, choose the repository's main branch.
6. Wait for the deployment to finish, then open the existing public URL and test it.

If you do not mind using a new URL, you can instead upload the ZIP to [Vercel Drop](https://vercel.com/drop). Each Drop creates a separate project.

## B. Enable student accounts, cloud progress and the leaderboard

These features are included in the code but will remain disabled until you configure a Supabase project.

1. Create a project at [Supabase](https://supabase.com/).
2. In Supabase, open **SQL Editor**, create a new query, paste the contents of `supabase-setup.sql`, and run it.
3. In Supabase project settings, copy the **Project URL** and the **public anon/publishable key**. Never use the `service_role` key in a browser app.
4. Open `config.js` in a text editor and fill in the two empty values:
   - `url`: your Supabase Project URL
   - `anonKey`: your public anon/publishable key
5. Save the file and redeploy the updated project.
6. In Supabase Auth settings, check the site URL and allowed redirect URLs. Add your live Vercel URL.
7. Test account creation, email confirmation if enabled, sign-in, completing a quiz, **My progress**, and **Student leaderboard**.

The leaderboard shares display names, exam names and scores with other users. Ask students to choose a non-identifying display name. Do not publish their real names or other personal details without their permission.

## C. Install on Android

1. Open the deployed HTTPS website in Chrome.
2. Tap **Install app** if Chrome offers the install prompt, or tap **⋮ → Install app / Add to Home screen**.
3. Confirm the installation. Open the app once online so the service worker can cache the quiz files for offline practice.

## D. Current question-bank note

The app currently contains 179 questions across three sets. The available MSI 2017 PDF substantially overlaps with the 34-question MSIS set and contains incomplete/ambiguous answer keys, so it is not added as a separate set until its unique questions and answers can be verified.
