# Anatomy MCQ Hub — updated Vercel PWA

This static app includes 179 existing MCQs across three exam sets (68 + 34 + 77). It preserves instant answer feedback, previous/next navigation, scores, review and device-local answer saving.

## Deploy/update on Vercel from Android
1. Download and extract `Anatomy_MCQ_Hub_Vercel_PWA_v2.zip`.
2. Deploy the extracted project folder using your preferred workflow. For the easiest repeatable workflow, put these files in a GitHub repository connected to your existing Vercel project; each commit will redeploy automatically.
3. Verify the site, then open it in Chrome on Android and use **⋮ → Install app** or **Add to Home screen**.

## PWA improvements
- Includes 192×192 and 512×512 PNG icons and a web app manifest.
- Service worker caches app files for offline quiz practice after a successful first visit.
- The Install app button uses the browser install prompt when supported and gives Android instructions otherwise.

## Student accounts and leaderboard (requires setup)
Quiz practice works without an account. To enable real accounts, personal cloud progress, and shared scores, create a Supabase project, run `supabase-setup.sql` in its SQL Editor, and copy the project URL and public anon/publishable key into `config.js`, then redeploy. **Never put a service-role key in browser code.** Configure email confirmation and password reset in Supabase Auth before inviting students.

Leaderboard displays display names, exam names and scores only. Use non-identifying display names and tell students that scores are shared before they join.

## Existing exam set limitations
The 2015 set has no explanations in its source file, so the app does not invent explanations. The uploaded MSI 2017 PDF overlaps substantially with the MSIS set and has incomplete/ambiguous answer keys; it has not been added as a separate set to avoid duplicate or unverified questions. It can be reviewed and merged once unique questions and answer keys are confirmed.


### Question explanations
All 77 questions in the 2015 MS Anatomy set now include concise explanations. A few items in the source answer key appear ambiguous or incorrect; the explanation explicitly flags those for review rather than presenting the supplied key as unquestionable. The January 2026 and MSIS sets retain their existing explanations.
