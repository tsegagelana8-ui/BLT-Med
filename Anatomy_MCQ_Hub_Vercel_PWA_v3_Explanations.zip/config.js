// Optional cloud student accounts. Keep only the Supabase project URL and public anon/publishable key here.
// Never place a service_role key or any secret key in this file.
window.SUPABASE_CONFIG = {
  url: "",
  anonKey: ""
};
